# Project notes

## Portfolio positioning

The page positions Smita Gautam as a Software Engineer with four connected strengths:

1. Full-stack product engineering
2. Backend, data and performance work
3. AI evaluation and model-reliability work
4. Reproducible containerized infrastructure

## Source discipline

All professional roles, project names, technologies, education and certification shown on the site are derived from the supplied résumé. No performance metrics, social links, awards or claims of availability were invented.

## Privacy choice

The résumé contains a phone number, but the public portfolio intentionally omits it. The public email address is included because the site needs a contact method and it is already presented as a professional contact in the supplied résumé.
