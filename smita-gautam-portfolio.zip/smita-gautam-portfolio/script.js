(() => {
  const html = document.documentElement;
  const themeToggle = document.getElementById('themeToggle');
  const navToggle = document.getElementById('navToggle');
  const navLinks = document.getElementById('navLinks');
  const progress = document.getElementById('scrollProgress');
  const filterButtons = [...document.querySelectorAll('.filter-btn')];
  const projectCards = [...document.querySelectorAll('.project-card')];
  const dialog = document.getElementById('commandDialog');
  const commandButton = document.getElementById('commandButton');
  const commandClose = document.getElementById('commandClose');
  const copyEmail = document.getElementById('copyEmail');
  const toast = document.getElementById('toast');
  const publicEmail = 'smita2003g@gmail.com';

  const savedTheme = localStorage.getItem('smita-theme');
  const prefersLight = window.matchMedia('(prefers-color-scheme: light)').matches;
  html.dataset.theme = savedTheme || (prefersLight ? 'light' : 'dark');

  function showToast(message) {
    toast.textContent = message;
    toast.classList.add('show');
    window.clearTimeout(showToast.timer);
    showToast.timer = window.setTimeout(() => toast.classList.remove('show'), 1800);
  }

  function toggleTheme() {
    const next = html.dataset.theme === 'dark' ? 'light' : 'dark';
    html.dataset.theme = next;
    localStorage.setItem('smita-theme', next);
    showToast(`${next[0].toUpperCase()}${next.slice(1)} theme enabled`);
  }

  themeToggle?.addEventListener('click', toggleTheme);

  navToggle?.addEventListener('click', () => {
    const open = navToggle.getAttribute('aria-expanded') === 'true';
    navToggle.setAttribute('aria-expanded', String(!open));
    navLinks.classList.toggle('open', !open);
  });

  navLinks?.addEventListener('click', (event) => {
    if (event.target.closest('a')) {
      navLinks.classList.remove('open');
      navToggle?.setAttribute('aria-expanded', 'false');
    }
  });

  function updateProgress() {
    const max = document.documentElement.scrollHeight - window.innerHeight;
    const ratio = max > 0 ? window.scrollY / max : 0;
    progress.style.width = `${Math.min(1, Math.max(0, ratio)) * 100}%`;
  }
  updateProgress();
  window.addEventListener('scroll', updateProgress, { passive: true });

  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('in-view');
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  document.querySelectorAll('.reveal').forEach((node) => revealObserver.observe(node));

  const sectionLinks = [...document.querySelectorAll('.nav-links a')];
  const sectionMap = new Map(sectionLinks.map((link) => [link.getAttribute('href')?.slice(1), link]));
  const sections = [...document.querySelectorAll('main section[id]')].filter((section) => sectionMap.has(section.id));
  const navObserver = new IntersectionObserver((entries) => {
    const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
    if (!visible) return;
    sectionLinks.forEach((link) => link.classList.remove('active'));
    sectionMap.get(visible.target.id)?.classList.add('active');
  }, { rootMargin: '-20% 0px -65% 0px', threshold: [0, 0.1, 0.5] });
  sections.forEach((section) => navObserver.observe(section));

  filterButtons.forEach((button) => {
    button.addEventListener('click', () => {
      const filter = button.dataset.filter;
      filterButtons.forEach((item) => {
        const active = item === button;
        item.classList.toggle('active', active);
        item.setAttribute('aria-pressed', String(active));
      });
      projectCards.forEach((card) => {
        const show = filter === 'all' || card.dataset.category === filter;
        card.classList.toggle('is-hidden', !show);
      });
    });
  });

  async function copyPublicEmail() {
    try {
      await navigator.clipboard.writeText(publicEmail);
      showToast('Email copied');
    } catch {
      window.location.href = `mailto:${publicEmail}`;
    }
  }
  copyEmail?.addEventListener('click', copyPublicEmail);

  function openDialog() {
    if (!dialog.open) dialog.showModal();
  }
  function closeDialog() {
    if (dialog.open) dialog.close();
  }
  commandButton?.addEventListener('click', openDialog);
  commandClose?.addEventListener('click', closeDialog);

  dialog?.addEventListener('click', (event) => {
    const bounds = dialog.getBoundingClientRect();
    const outside = event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom;
    if (outside) closeDialog();

    const targetButton = event.target.closest('[data-command-target]');
    if (targetButton) {
      closeDialog();
      document.querySelector(targetButton.dataset.commandTarget)?.scrollIntoView({ behavior: 'smooth' });
    }
    if (event.target.closest('[data-copy-command="email"]')) copyPublicEmail();
    if (event.target.closest('[data-theme-command="toggle"]')) toggleTheme();
  });

  window.addEventListener('keydown', (event) => {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
      event.preventDefault();
      dialog.open ? closeDialog() : openDialog();
      return;
    }
    if (!dialog.open) return;
    const keyMap = { '1': '#expertise', '2': '#experience', '3': '#projects', '4': '#evaluation', '5': '#stack', '6': '#contact' };
    if (keyMap[event.key]) {
      closeDialog();
      document.querySelector(keyMap[event.key])?.scrollIntoView({ behavior: 'smooth' });
    } else if (event.key.toLowerCase() === 'c') {
      copyPublicEmail();
    } else if (event.key.toLowerCase() === 't') {
      toggleTheme();
    }
  });
})();
