# Smita Gautam — Software Engineering Portfolio

A one-page software-engineering portfolio built around Smita Gautam's documented experience in full-stack development, backend systems, data and caching, containerized infrastructure, and AI evaluation.

## What makes the site different

- Responsive, dependency-free architecture: HTML, CSS and JavaScript only.
- Interactive project filtering across full-stack, machine-learning and AI-backend work.
- AI-evaluation engineering loop based on real professional responsibilities.
- Keyboard command palette with `Ctrl/⌘ K` navigation.
- Light/dark theme persistence.
- Scroll progress, active navigation, reveal transitions and mobile navigation.
- Accessibility support including semantic landmarks, focus states, a skip link and reduced-motion handling.
- Structured SEO metadata and Person JSON-LD.
- GitHub Actions quality checks using Node.js only; no package install is required.

## Public content policy

The site intentionally uses only professional information from the supplied résumé. A phone number is not published. No LinkedIn or GitHub profile URL is invented; those can be added after the real links are supplied.

## Run locally

No dependencies are required.

```bash
python3 -m http.server 4173
```

Then open `http://localhost:4173`.

You can also open `index.html` directly in a browser, although serving it locally is closer to production behavior.

## Verify

```bash
node scripts/check.mjs
node --check script.js
```

The repository also runs the same checks in GitHub Actions on pushes and pull requests.

## Deploy

### Vercel

Import this repository as a new Vercel project. It is a static website, so no build command or framework configuration is required.

### GitHub Pages

The repository can also be served as a static site from GitHub Pages if desired.

## Customize later

When the real links are available, add:

- GitHub profile/repository URL
- LinkedIn profile URL
- Optional real profile photograph

Keep public contact information limited to details intended for recruiters and collaborators.
